/*eslint-disable*/
var ScheduleViewModel = require('model/viewModel/scheduleViewModel');

describe('ScheduleViewModel', function() {
});
